<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AnimalController;
use App\Http\Controllers\Api\CategoryController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//  // Animal
Route::get('/animals', [AnimalController::class, 'index']); // all animals
Route::delete('/animals/{id}', [AnimalController::class, 'destroy']); // delete animal
Route::post('/animals', [AnimalController::class, 'store']); // create animal
Route::get('/animals/{id}', [AnimalController::class, 'show']); // get single animal
Route::put('/animals/{id}', [AnimalController::class, 'update']); // update animal
Route::get('/category-animals/{id}', [AnimalController::class, 'getPostByCategory']); // get Animals by Category ID/ All animals in that category

// Using Get call the api route like this: http://localhost:8000/api/category-animals/7  no.7 represent the id

 // Category
Route::get('/category', [CategoryController::class, 'index']); // all category
Route::delete('/category/{id}', [CategoryController::class, 'destroy']); // delete animal
Route::post('/category', [CategoryController::class, 'store']); // create Category
Route::get('/category/{id}', [CategoryController::class, 'show']); // get single Category
Route::put('/category/{id}', [CategoryController::class, 'update']); // update Category

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });