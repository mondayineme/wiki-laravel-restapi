<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Animal;
use App\Models\Category;
use Illuminate\Http\Request;

class AnimalController extends Controller
{
    
    public function index()
    {
        return response([
            'animals' => Animal::orderBy('created_at', 'desc')->with('category:id,name')->get()
        ], 200);
    }

    public function store(Request $request)
    {
        //validate fields
        $attrs = $request->validate([
            'name' => 'required|string',
            'botanical_name' => 'required|string',
            'category_id' => 'required|integer'
        ]);

        $animal = Animal::create([
            'name' => $attrs['name'],
            'botanical_name' => $attrs['botanical_name'],
            'category_id' => $attrs['category_id']
        ]);

        // for now skip for animal image

        return response([
            'message' => 'Animal created.',
            'animal' => $animal,
        ], 200);
    }

    public function show($id)
    {
        return response([
            'animal' => Animal::where('id', $id)->get()
        ], 200);
    }

    public function update(Request $request, $id)
    {
        $animal = Animal::find($id);

        if(!$animal)
        {
            return response([
                'message' => 'Animal not found.'
            ], 403);
        }

        //validate fields
        $attrs = $request->validate([
            'name' => 'required|string',
            'botanical_name' => 'required|string',
            'category_id' => 'required|integer'
        ]);

        $animal->update([
            'name' => $attrs['name'],
            'botanical_name' => $attrs['botanical_name'],
            'category_id' => $attrs['category_id']
        ]);

        // for now skip for animal image

        return response([
            'message' => 'Animal updated.',
            'animal' => $animal
        ], 200);
    }

    public function destroy($id)
    {
        $animal = Animal::find($id);

        if(!$animal)
        {
            return response([
                'message' => 'Animal not found.'
            ], 403);
        }

        $animal->delete();

        return response([
            'message' => 'Animal deleted.'
        ], 200);
    }

    public function getPostByCategory($id)
    {
        try {
            $animals = Animal::with('categorys')->where('category_id', $id)->orderBy('id', 'desc')->get();
            return $animals->where('category_id', $id);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ]);
        }
    }

}