<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        return response([
            'categories' => Category::orderBy('created_at', 'desc')->get()
        ], 200);
    }

    public function store(Request $request)
    {
        //validate fields
        $attrs = $request->validate([
            'name' => 'required|string'
        ]);

        $category = Category::create([
            'name' => $attrs['name']
        ]);

        return response([
            'message' => 'Category created.',
            'category' => $category,
        ], 200);
    }

    public function show($id)
    {
        return response([
            'category' => Category::where('id', $id)->get()
        ], 200);
    }

    public function update(Request $request, $id)
    {
         $category = Category::find($id);

        if(!$category)
        {
            return response([
                'message' => 'Category not found.'
            ], 403);
        }

        //validate fields
        $attrs = $request->validate([
            'name' => 'required|string'
        ]);

        $category->update([
            'name' => $attrs['name']
        ]);

        // for now skip for category image

        return response([
            'message' => 'Category updated.',
            'category' => $category
        ], 200);
    }

    public function destroy($id)
    {
        $category = Category::find($id);

        if(!$category)
        {
            return response([
                'message' => 'Category not found.'
            ], 403);
        }

        $category->delete();

        return response([
            'message' => 'Category deleted.'
        ], 200);
    }

}